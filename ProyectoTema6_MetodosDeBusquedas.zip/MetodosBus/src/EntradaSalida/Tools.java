package EntradaSalida;

import javax.swing.JOptionPane;

public class Tools {
    
     public static void imprimeMSJ(String msj){
        JOptionPane.showMessageDialog(null, msj);
    }
 
    ///// LEE ENTERO 
    public static int leeEntero(String msg){
        int x;
        try{
            x = Integer.parseInt(JOptionPane.showInputDialog(msg));
            return x;
        }
        catch(NumberFormatException e){
            System.out.println("¡Solo se aceptan Numeros!");
        }
        return 0;
    }
    
    /////////////////// METODOS NUEVOS 
    
    /// LEE STRING 
    public static String leeString(String msg){ 
        try{
            return (JOptionPane.showInputDialog(null, msg, "String", JOptionPane.INFORMATION_MESSAGE));
        }
        catch(NumberFormatException e){
            System.out.println("¡Solo se aceptan Letras!");
        }
        return null;           
    }
   
    /// LEE ENTERO
    public static int leeInteger(String msg){
        try{
            return (Integer.parseInt(JOptionPane.showInputDialog(null, msg, "Integer", JOptionPane.INFORMATION_MESSAGE)));
        }
        catch(NumberFormatException e){
            System.out.println("¡Solo se aceptan Numeros!");
        }
        return 0;     
    }
    
    /// LEE FLOTANTE 
    public static float leeFloat(String msg){
        try{
            return (Float.parseFloat(JOptionPane.showInputDialog(null, msg, "Float", JOptionPane.INFORMATION_MESSAGE)));
        }
        catch(NumberFormatException e){
            System.out.println("¡Solo se aceptan Numeros!");
        }
        return 0;     
    }
    
    /// LEE BYTE 
    public static byte leeByte(String msg){
        try{
            return (Byte.parseByte(JOptionPane.showInputDialog(null, msg, "Byte", JOptionPane.INFORMATION_MESSAGE)));
        }
        catch(NumberFormatException e){
            System.out.println("¡Solo se aceptan Numeros!");
        }
        return 0;     
    }
    
    /// LEE SHORT 
    public static short leeShort(String msg){
        try{
            return (Short.parseShort(JOptionPane.showInputDialog(null, msg, "Short", JOptionPane.INFORMATION_MESSAGE)));
        }
        catch(NumberFormatException e){
            System.out.println("¡Solo se aceptan Numeros!");
        }
        return 0;     
    }
    
    /// LEE CHAR
    public static char leeChar(String msg){
        try{
            return (JOptionPane.showInputDialog(null, msg, "Char", JOptionPane.INFORMATION_MESSAGE).charAt(0));
        }
        catch(NumberFormatException e){
            System.out.println("¡Solo se aceptan Numeros!");
        }
        return 0;     
    }
    
    /// LEE LONG 
    public static long leeLong(String msg){
        try{
            return (Long.parseLong(JOptionPane.showInputDialog(null, msg, "Long", JOptionPane.INFORMATION_MESSAGE)));
        }
        catch(NumberFormatException e){
            System.out.println("¡Solo se aceptan Numeros!");
        }
        return 0;     
    }
    
    /// LEE DOUBLE
    public static double leeDouble(String msg){
        try{
            return (Double.parseDouble(JOptionPane.showInputDialog(null, msg, "Double", JOptionPane.INFORMATION_MESSAGE)));
        }
        catch(NumberFormatException e){
            System.out.println("¡Solo se aceptan Numeros!");
        }
        return 0;     
    }
    
    /// LEE BOOLEAN
    public static boolean leeBoolean(String msg){
        try{
            return (Boolean.parseBoolean(JOptionPane.showInputDialog(null, msg, "Boolean", JOptionPane.INFORMATION_MESSAGE)));
        }
        catch(NumberFormatException e){
            System.out.println("¡Solo se aceptan Numeros!");
        }
        return false;
            
    }
    
}