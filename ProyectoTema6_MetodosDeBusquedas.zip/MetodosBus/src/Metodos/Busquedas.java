package Metodos;
import EntradaSalida.Tools;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Busquedas {
    
    private int datos[];
    private byte J;
    
    public Busquedas(int tam){
        datos = new int[tam];
        J = -1;
    }
    
    public boolean arrayVacio(){
        return (J == -1);
    }
    
    public void agregarDatos(){
        if(J < datos.length -1){
            datos[J+1] = Tools.leeEntero("Escribe un valor: ");
            J++;
        } else{
            JOptionPane.showMessageDialog(null, "Array lleno.");
        }
    }
    
public void ordenarDatos() {
    boolean intercambio;
    int n = datos.length;
    
    do {
        intercambio = false;
        
        for (int i = 0; i < n - 1; i++) {
            if (datos[i] > datos[i + 1]) {
                // Intercambiar elementos
                int temp = datos[i];
                datos[i] = datos[i + 1];
                datos[i + 1] = temp;
                
                intercambio = true;
            }
        }
        
        n--;
    } while (intercambio);
}

    public void imprimirArray(){
        String cad = "";
        for (int i = 0; i <= J; i++) {
            cad += "[" + i + "]" + " - " + datos[i] + "\n";       
        }
        JOptionPane.showMessageDialog(null, "Datos del Array:" + "\n" + cad);
    }
    
    // PRIMER METODO - BUSQUEDA SECUENCIAL 
    public byte buscarSecuencial(int dato){
        byte i =0;
        while(i <= J && dato!= datos[i])
        i++;     
        if(i<=J){
            return i;
        }
        else{
            return (-1);
        } 
    }
    
    // SEGUNDO METODO - BUSQUEDA BINARIA
    public byte busquedaBinaria(int dato) {
        ordenarDatos();
        int aux = 0;
        int de = datos.length - 1;
        
        while (aux <= de) {
            int mitad = aux + (de - aux) / 2;
            
            if (datos[mitad] == dato) {
                return (byte) mitad;
            } else if (datos[mitad] < dato) {
                aux = mitad + 1;
            } else {
                de = mitad - 1;
            }
        }
        return (byte) (-(aux + 1));
    }
    
    // TERCER METODO - PATRONES KNUTH MORRIS PRATT    
    public static List<Integer> busquedaKMP(String texto, String patron) {
        List<Integer> coincidencias = new ArrayList<>();
        int n = texto.length();
        int m = patron.length();
        int[] tabla = tablaPrefijos(patron);

        int i = 0; // Índice para el texto
        int j = 0; // Índice para el patrón

        while (i < n) {
            if (patron.charAt(j) == texto.charAt(i)) {
                j++;
                i++;
            }

            if (j == m) {
                coincidencias.add(i - j);
                j = tabla[j - 1];
            } else if (i < n && patron.charAt(j) != texto.charAt(i)) {
                if (j != 0) {
                    j = tabla[j - 1];
                } else {
                    i++;
                }
            }
        }

        return coincidencias;
    }

    private static int[] tablaPrefijos(String patron) {
        int m = patron.length();
        int[] lps = new int[m];
        int len = 0; // Longitud del sufijo más largo previo

        int i = 1;
        while (i < m) {
            if (patron.charAt(i) == patron.charAt(len)) {
                len++;
                lps[i] = len;
                i++;
            } else {
                if (len != 0) {
                    len = lps[len - 1];
                } else {
                    lps[i] = 0;
                    i++;
                }
            }
        }

        return lps;
    }
    
    
    // CUARTO METODO - SALTAR BUSQUEDA 
    public int saltarBusqueda(int valor) {
        ordenarDatos();
        int inicio = 0;
        int fin = datos.length;
        int tbloque = (int) Math.sqrt(datos.length);

        while (datos[Math.min(fin - 1, datos.length - 1)] <= valor && fin < datos.length) {
            inicio = fin;
            fin = fin + tbloque;
            if (fin > datos.length - 1) {
                fin = datos.length;
            }
        }

        for (int i = inicio; i < fin; i++) {
            if (datos[i] == valor) {
                return i;
            }
        }

        return -1;
    }
    // QUINTO METODO - BUSQUEDA DE INTERPOLACION
    public byte busquedaInterpolacion(int dato) {
       // ordenarDatos();
        int izq = 0;
        int der = datos.length - 1;
        while (izq <= der && dato >= datos[izq] && dato <= datos[der]) {
            if (izq == der) {
                if (datos[izq] == dato) {
                    return (byte) izq;
                }
                return -1;
            }       
            int pos = izq + (((der - izq) / (datos[der] - datos[izq])) * (dato - datos[izq]));
            
            if (datos[pos] == dato) {
            }
            
            if (datos[pos] < dato) {
                izq = pos + 1;
            } else {
                der = pos - 1;
            }
        }
        return -1;
    }  
    
    // SEXTO METODO - BUSQUEDA EXPONENCIAL
public byte busquedaExponencial(int dato) {
    ordenarDatos();

    if (dato == datos[0]) {
        return 0; // Dato en posición inicial
    }

    int i = 1;
    while (i <= J && datos[i] <= dato) {
        i *= 2;
    }

    // Verificar si se superó el tamaño del array
    int exi = Math.min(i, J + 1);
    if (exi == datos.length) {
        exi--; // Ajustar el índice para que no esté fuera de rango
    }

    return busquedaBinariaRecursiva(dato, i / 2, exi);
}

private byte busquedaBinariaRecursiva(int dato, int aux, int exi) {
    if (aux > exi) {
        return -1; // El dato no se encuentra en el array
    }

    int medio = aux + (exi - aux) / 2;

    if (datos[medio] == dato) {
        return (byte) medio;
    } else if (datos[medio] > dato) {
        return busquedaBinariaRecursiva(dato, aux, medio - 1);
    } else {
        return busquedaBinariaRecursiva(dato, medio + 1, exi);
    }
}  
    // SEPTIMO METODO - BUSQUEDA FIBONACCI
    public byte busquedaFibonacci(int dato) {
        ordenarDatos();
        int fib2 = 0; // num anterior
        int fib1 = 1; // num actual
        int fib = fib2 + fib1; // num siguiente

        while (fib <= J + 1) {
            if (datos[fib - 1] == dato) {
                return (byte) (fib - 1);
            } else if (datos[fib - 1] < dato) {
                fib2 = fib1;
                fib1 = fib;
                fib = fib2 + fib1;
            } else {
                break;
            }
        }
        int aux = -1;

        while (fib > 1) {
            int i = Math.min(aux + fib2, J);

            if (datos[i] < dato) {
                fib = fib1;
                fib1 = fib2;
                fib2 = fib - fib1;
                aux = i;
            } else if (datos[i] > dato) {
                fib = fib2;
                fib1 = fib1 - fib2;
                fib2 = fib - fib1;
            } else {
                return (byte) i;
            }
        }
        return -1;
    }
       
}