package TestMetodos;

import EntradaSalida.Tools;
import Metodos.Busquedas;
import static Metodos.Busquedas.busquedaKMP;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Menu {

    public static String menuDesplegable(String opciones[]) {
        String rutaIco = "imagen.png";
        ImageIcon obIco = new ImageIcon(rutaIco);
        String opcion;
        opcion = (String) JOptionPane.showInputDialog(null, "Selecciona ",
                "Elegir", JOptionPane.ERROR_MESSAGE, obIco, opciones, opciones[0]);
        return opcion;
    }

    public void menu() {

        String opciones[] = {"AGREGAR DATOS", "IMPRIMIR DATOS", "BUSQUEDA SECUENCIAL", "BUSQUEDA BINARIA",
            "KNUTH MORRIS P", "SALTAR BUSQUEDA", "INTERPOLACION", "BUSQUEDA EXPONENCIAL", "BUSQUEDA DE FIBONACCI", "Terminar"};
        String opc = null;
        int dato;
        int n = Tools.leeInteger("¿Cuántos números desea agregar?");
        Busquedas objB = new Busquedas(n);

        while (!(opc = menuDesplegable(opciones)).equals("Terminar")) {
            switch (opc) {
                case "AGREGAR DATOS":
                    objB.agregarDatos();
                    break;
                case "IMPRIMIR DATOS":
                    objB.imprimirArray();
                    break;
                case "BUSQUEDA SECUENCIAL":
                    if (objB.arrayVacio()) {
                        Tools.imprimeMSJ("El Array esta vacio.");
                    } else {
                        byte datoBuscado = Tools.leeByte("Ingresa el Dato que desea buscar: ");
                        byte resultadoBusqueda = objB.buscarSecuencial(datoBuscado);
                        if (resultadoBusqueda != -1) {
                            JOptionPane.showMessageDialog(null, "Número encontrado en la posición: [" + resultadoBusqueda + "]",
                                    "Busqueda Secuencial", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(null,
                                    "No se encontro el numero", "Busqueda secuencial",
                                    JOptionPane.WARNING_MESSAGE);
                        }
                    }
                    break;

                case "BUSQUEDA BINARIA":
                    if (objB.arrayVacio()) {
                        Tools.imprimeMSJ("El Array esta vacio.");
                    } else {
                        dato = Tools.leeEntero("Ingrese Dato a Buscar: ");
                        int resultadoBusqueda = objB.busquedaBinaria(dato);
                        if (resultadoBusqueda >= 0) {
                            JOptionPane.showMessageDialog(null, "Número encontrado en la posición: [" + resultadoBusqueda + "]",
                                    "Busqueda Secuencial", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(null,
                                    "No se encontro el numero", "Busqueda secuencial",
                                    JOptionPane.WARNING_MESSAGE);
                        }
                    }
                    break;

                case "INTERPOLACION":
                    if (objB.arrayVacio()) {
                        Tools.imprimeMSJ("El Array está vacío.");
                    } else {
                        int datoBuscado = Tools.leeEntero("Ingresa el Dato que deseas buscar: ");
                        byte resultadoBusqueda = objB.busquedaInterpolacion(datoBuscado);
                        if (resultadoBusqueda >= 0) {
                            JOptionPane.showMessageDialog(null, "Número encontrado en la posición: [" + resultadoBusqueda + "]",
                                    "Búsqueda de Interpolación", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(null, "No se encontró el número", "Búsqueda de Interpolación",
                                    JOptionPane.WARNING_MESSAGE);
                        }
                    }
                    break;

                case "BUSQUEDA EXPONENCIAL":
                    if (objB.arrayVacio()) {
                        Tools.imprimeMSJ("El Array está vacío.");
                    } else {
                        int datoBuscado = Tools.leeEntero("Ingresa el dato que deseas buscar: ");
                        byte resultadoBusqueda = objB.busquedaExponencial(datoBuscado);
                        if (resultadoBusqueda >= 0) {
                            JOptionPane.showMessageDialog(null, "Número encontrado en la posición: [" + resultadoBusqueda + "]",
                                    "Búsqueda Exponencial", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(null, "No se encontró el número", "Búsqueda Exponencial",
                                    JOptionPane.WARNING_MESSAGE);
                        }
                    }
                    break;

                case "BUSQUEDA DE FIBONACCI":
                    if (objB.arrayVacio()) {
                        Tools.imprimeMSJ("El Array está vacío.");
                    } else {
                        int datoBuscado = Tools.leeEntero("Ingresa el dato que deseas buscar: ");
                        byte resultadoBusqueda = objB.busquedaFibonacci(datoBuscado);
                        if (resultadoBusqueda > -1) {
                            JOptionPane.showMessageDialog(null, "Número encontrado en la posición: [" + resultadoBusqueda + "]",
                                    "Búsqueda Fibonacci", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(null,
                                    "No se encontró el número", "Búsqueda Fibonacci",
                                    JOptionPane.WARNING_MESSAGE);
                        }
                    }
                    break;
                case "SALTAR BUSQUEDA":
                    if (objB.arrayVacio()) {
                        Tools.imprimeMSJ("El Array esta vacio.");
                    } else {
                        int datoBuscado = Tools.leeByte("Ingresa el Dato que desea buscar: ");
                        int resultadoBusqueda = objB.saltarBusqueda(datoBuscado);
                        if (resultadoBusqueda != -1) {
                            JOptionPane.showMessageDialog(null, "Número encontrado en la posición: [" + resultadoBusqueda + "]",
                                    "SALTAR BUSQUEDA", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(null,
                                    "No se encontro el numero", "SALTAR BUSQUEDA",
                                    JOptionPane.WARNING_MESSAGE);
                        }
                    }
                    break;
                case "Terminar":
                    break;
            }
        }
    }

    public void ordenamientoCadena() {
        String opciones[] = {"KNUTH MORRIS P", "Terminar"};
        String opc = null;

        while (!(opc = menuDesplegable(opciones)).equals("Terminar")) {
            switch (opc) {
                case "KNUTH MORRIS P":
                    String texto = Tools.leeString("Ingrese la cadena de texto en la que desea buscar un patrón:");
                    //"CTCACTGCCTGCCTAG";
                    String patron = Tools.leeString("Ingrese el patrón que desea  buscar en el texto:");
                    //"CTGCCTAG";
                    List<Integer> res = busquedaKMP(texto, patron);

                    if (res.isEmpty()) {
                        Tools.imprimeMSJ("No se encontraron coincidencias del patrón en el texto.");
                    } else {
                        Tools.imprimeMSJ("Coincidencias encontradas en los índices: " + res);
                    }
                    break;
                case "Terminar":
                    break;
            }
        }
    }

    public static void main(String[] args) {
        Menu obj = new Menu();
        int op;
        do {
            op = Tools.leeInteger("          Métodos de Búsquedas.\n1.Búsquedas en arreglo de números."
                    + "\n2.Búsqueda en cadena de texto.\n3.Salir.");
            if (op == 1) {
                obj.menu();
            } else if (op == 2) {obj.ordenamientoCadena();
            }
        } while (op != 3);
    }
}