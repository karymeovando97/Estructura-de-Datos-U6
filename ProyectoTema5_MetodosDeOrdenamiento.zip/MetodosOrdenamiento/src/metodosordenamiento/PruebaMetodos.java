package metodosordenamiento;
import EntradaSalida.Tools;
import Metodos.Ordenamientos;
import javax.swing.JOptionPane;
public class PruebaMetodos {

    //MENU DE CLASE 
    public static void testMetodos(String menu) {
        int n = Tools.leeInt("¿Cuántos números aleatorios desea agregar?");
        Ordenamientos metodos = new Ordenamientos(n);
        
        //para ahorrar una selección, al momento de introduccir cuantos datos desea
        //se agregarán automáticamente con la siguiente condición:
        while (metodos.espacioArray()) {
            metodos.almacenaAleatorios();
        }
        Tools.imprime("Se han agregado correctamente " + n + 
                " datos al arreglo:\n" + metodos.impresionDatos());

        String op;
        do {
            op = desplegable(menu);
            switch (op) {
                case "Burbuja con señal":
                    if (metodos.arrayVacio()) Tools.errorMsj("Array vacío!");
                    else metodos.burbujaSeñal();
                    break;
                case "Doble burbuja con señal":
                    if (metodos.arrayVacio()) Tools.errorMsj("Array vacío!");
                    else metodos.dobleBurbuja();
                    break;
                case "Shell":
                    if (metodos.arrayVacio()) Tools.errorMsj("Array vacío!");
                    else metodos.shellIncreDecre();
                    break;
                case "Selección directa":
                    if (metodos.arrayVacio()) Tools.errorMsj("Array vacío!");
                    else metodos.seleDirecta();
                    break;
                case "Inserción directa":
                    if (metodos.arrayVacio()) Tools.errorMsj("Array vacío!");
                    else metodos.inserDirecta();
                    break;
                case "Binaria":
                    if (metodos.arrayVacio()) Tools.errorMsj("Array vacío!");
                    else metodos.binaria();
                    break;
                case "Heap Sort":
                    if (metodos.arrayVacio()) Tools.errorMsj("Array vacío!");
                    else metodos.headSort();
                    break;
                case "Quick Sort Recursivo":
                    if (metodos.arrayVacio()) Tools.errorMsj("Array vacío!");
                    else metodos.quickSortRecursivo();
                    break;
                case "Intercalación":
                    if (metodos.arrayVacio()) Tools.errorMsj("Array vacío!");
                    else metodos.intercalacion();
                    break;
                case "Mezcla directa":
                    if (metodos.arrayVacio()) Tools.errorMsj("Array vacío!");
                    else metodos.mezclaDirecta();
                    break;
                case "Radix":
                    if (metodos.arrayVacio()) Tools.errorMsj("Array vacío!");
                    else metodos.radix();
                    break;
                case "Imprimir":
                    if (metodos.arrayVacio()) {
                        Tools.errorMsj("Array vacío!");
                    } else {
                        Tools.imprime("Datos:\n" + metodos.impresionDatos());
                    }
        } }while (!op.equals("Salir"));
    }
        
    
        
    
    public static String desplegable(String menu) {
        String valores[] = menu.split(",");
        String res = (String) JOptionPane.showInputDialog(null,"M E N U",
                "¿Qué método de ordenamiento desea?:",JOptionPane.QUESTION_MESSAGE,null,valores,valores[0]);
    return (res);
    }
    
    public static void main(String[] args) {
        String menu = "Agregar,Burbuja con señal,Doble burbuja con señal,"
                + "Shell,Selección directa,Inserción directa,Binaria,"
                + "Heap Sort,Quick Sort Recursivo,Intercalación,Mezcla directa,"
                + "Radix,Imprimir,Salir";
        int op;
        do {
            op = Tools.leeInt("¿Desea probar un método de ordenamiento?\n" 
                    + "1. Si\n2. No");
            if (op == 1) {
                testMetodos(menu);
            }
        } while (op != 2);

        Tools.imprime("Programa terminado");
    }
    
}