package Metodos;

public interface MetodosO {
    
    public boolean arrayVacio();
    public boolean espacioArray();
    public void vaciarArray();
    public void almacenaAleatorios();
    public String impresionDatos();
    public int generaRandom(int min, int max);
    //métodos de ordenamiento:
    public void burbujaSeñal();
    public void dobleBurbuja();
    public void shellIncreDecre();
    public void seleDirecta();
    public void inserDirecta();
    public void binaria();
    public void headSort();
    public void quickSortRecursivo();
    public void radix();
    public void intercalacion(); //mezcla simple
    public void mezclaDirecta();
    
}
