package Metodos;

import EntradaSalida.Tools;
import java.util.Arrays;

public class Ordenamientos implements MetodosO {

    private int[] array;
    private byte i;

    public Ordenamientos(int tam) {
        array = new int[tam];
        i = -1;
    }

    @Override
    public boolean arrayVacio() {
        return (i == -1);
    }

    @Override
    public boolean espacioArray() {
        return (i < array.length - 1);
        //si esto es cierto, hay espacio = true
    }

    @Override
    public void vaciarArray() {
        array = null;
        //declara que el array tendrá un contenido de null
        // es decir = vacio
    }

    @Override
    public void almacenaAleatorios() {
        array[i + 1] = generaRandom(10, 99);
        //mandamos esos valores para que los núm generados 
        //sean aleatorios compuestos de 2 cifras
        i++;
    }

    //*************
    public void agregaDatos() {
        array[i + 1] = Tools.leeInt("Ingrese un número:");
        i++;
    }

    //*********
    @Override
    public String impresionDatos() {
        String cad = "";

        for (int j = 0; j <= i; j++) {
            cad += "[" + j + "] = " + array[j] + "\n";
        }
        return cad;
    }

    @Override
    public int generaRandom(int min, int max) {
        return (int) ((max - min + 1) * Math.random() + min);
    }

    @Override
    public void burbujaSeñal() {
        if (arrayVacio() || i == 0) {
            return;
        }
        boolean intercambio;
        int n = i + 1;
        int izquierda = 0;
        int derecha = n - 1;
        int ultimaPosicion = derecha;

        do {
            intercambio = false;
            for (int j = izquierda; j < derecha; j++) {
                if (array[j] > array[j + 1]) {
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;

                    intercambio = true;
                    ultimaPosicion = j;
                }
            }

            derecha = ultimaPosicion;

            if (!intercambio) {
                break;
            }

            intercambio = false;

            // Fase descendente
            for (int j = derecha; j > izquierda; j--) {
                if (array[j] < array[j - 1]) {
                    // Intercambiar elementos
                    int temp = array[j];
                    array[j] = array[j - 1];
                    array[j - 1] = temp;

                    intercambio = true;
                    ultimaPosicion = j;
                }
            }

            izquierda = ultimaPosicion;

        } while (intercambio);
        Tools.imprime("Datos del array ordenados por Burbuja señal:\n" + Arrays.toString(array));
    }

    @Override
    public void dobleBurbuja() {
        if (arrayVacio() || i == 0) {
            return;
        }
        boolean intercambio;
        int n = i + 1;

        do {
            intercambio = false;
            for (int j = 0; j < n - 1; j++) {
                if (array[j] > array[j + 1]) {
                    // Intercambiar elementos
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;

                    intercambio = true;
                }
            }

            if (!intercambio) {
                break;
            }

            intercambio = false;

            // Fase descendente
            for (int j = n - 2; j >= 0; j--) {
                if (array[j] > array[j + 1]) {
                    // Intercambiar elementos
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;

                    intercambio = true;
                }
            }

        } while (intercambio);
        Tools.imprime("Datos del array ordenados por Doble burbuja: \n" + Arrays.toString(array));
    }

    @Override
    public void shellIncreDecre() {
        int n = array.length;
        int incre = n / 2;
        while (incre > 0) {
            for (int i = incre; i < n; i++) {
                int aux = array[i];
                int j = i;
                while (j >= incre && array[j - incre] > aux) {
                    array[j] = array[j - incre];
                    j = j - incre;
                }
                array[j] = aux;
            }
            if (incre == 2) {
                incre = 1;
            } else {
                incre /= 2.2;
            }
        }
        Tools.imprime("Datos del array ordenados por Shell:\n" + Arrays.toString(array));
    }

    @Override
    public void seleDirecta() {
        int n = array.length;
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (array[j] < array[minIndex]) {
                    minIndex = j;
                }
            }
            int aux = array[minIndex];
            array[minIndex] = array[i];
            array[i] = aux;
        }
        Tools.imprime("Datos del array ordenados por Selección directa: \n" + Arrays.toString(array));
    }

    @Override
    public void inserDirecta() {
        int n = array.length;
        for (int i = 1; i < n; i++) {
            int key = array[i];
            int j = i - 1;
            while (j >= 0 && array[j] > key) {
                array[j + 1] = array[j];
                j = j - 1;
            }
            array[j + 1] = key;
        }
        Tools.imprime("Datos del array ordenados por Inserción directa: \n" + Arrays.toString(array));

    }

    @Override
    public void binaria() {
        if (!arrayVacio()) {
            // Convertir los números a cadenas binarias
            String[] binaryStrings = new String[i + 1];
            for (int j = 0; j <= i; j++) {
                binaryStrings[j] = Integer.toBinaryString(array[j]);
            }

            // Ordenar las cadenas binarias de menor a mayor
            Arrays.sort(binaryStrings, (s1, s2) -> {
                int len1 = s1.length();
                int len2 = s2.length();

                if (len1 != len2) {
                    return len1 - len2;
                }

                return s1.compareTo(s2);
            });

            // Mostrar los números ordenados en binario
           // Tools.imprime("Números ordenados en binario de menor a mayor\n:");
            for (String binaryString : binaryStrings) {
                Tools.imprime("Números ordenados en binario de menor a mayor:\n" + binaryString);
            }
        }
    }

    @Override
    public void headSort() {
        int n = i + 1;
        // se construye el heap onstruir
        for (int i = n / 2 - 1; i >= 0; i--) {
            monticulo(n, i);
        }

        // elementos en orden ascendente
        for (int j = n - 1; j >= 0; j--) {
            int orden = array[0];
            array[0] = array[j];
            array[j] = orden;
            monticulo(j, 0);
        }
        Tools.imprime("Datos del array ordenados por Heap Sort: \n" + Arrays.toString(array));

    }

    // metodo para convertirlo 
    private void monticulo(int n, int i) {
        int mayor = i;  // agarrar la raiz con el mayor
        int izq = 2 * i + 1;
        int der = 2 * i + 2;

        // si izq es más grande que la raiz
        if (izq < n && array[izq] > array[mayor]) {
            mayor = izq;
        }

        // si der es más grande que la raiz
        if (der < n && array[der] > array[mayor]) {
            mayor = der;
        }

        // Si mayor no es raiz
        if (mayor != i) {
            int cambio = array[i];
            array[i] = array[mayor];
            array[mayor] = cambio;

            monticulo(n, mayor);
        }
    }

    @Override
    public void quickSortRecursivo() {
        quickSortRecursivo(0, i);
        Tools.imprime("Datos del array ordenados por Quick Sort Recursivo:\n" + Arrays.toString(array));

    }

    private void quickSortRecursivo(int izquierda, int derecha) {
        if (izquierda < derecha) {
            int indiceParticion = particion(izquierda, derecha);
            quickSortRecursivo(izquierda, indiceParticion - 1);
            quickSortRecursivo(indiceParticion + 1, derecha);
        }
    }

    private int particion(int izquierda, int derecha) {
        int pivote = array[derecha];
        int indiceParticion = izquierda - 1;

        for (int j = izquierda; j < derecha; j++) {
            if (array[j] <= pivote) {
                indiceParticion++;
                int temp = array[indiceParticion];
                array[indiceParticion] = array[j];
                array[j] = temp;
            }
        }
        int temp = array[indiceParticion + 1];
        array[indiceParticion + 1] = array[derecha];
        array[derecha] = temp;

        return indiceParticion + 1;
    }

    @Override
    public void intercalacion() {
        if (!arrayVacio()) {
            intercalacion(0, i);

            Tools.imprime("Datos del array ordenados por Intercalación:\n" + Arrays.toString(array));
        }
    }

    private void intercalacion(int bajo, int alto) {
        if (bajo < alto) {
            int medio = (bajo + alto) / 2;
            intercalacion(bajo, medio);
            intercalacion(medio + 1, alto);
            fusion(bajo, medio, alto);
        }
    }

    private void fusion(int bajo, int medio, int alto) {
        int[] izquierda = new int[medio - bajo + 1];
        int[] derecha = new int[alto - medio];

        for (int i = 0; i < izquierda.length; i++) {
            izquierda[i] = array[bajo + i];
        }

        for (int i = 0; i < derecha.length; i++) {
            derecha[i] = array[medio + 1 + i];
        }

        int i = 0, j = 0, k = bajo;

        while (i < izquierda.length && j < derecha.length) {
            if (izquierda[i] <= derecha[j]) {
                array[k] = izquierda[i];
                i++;
            } else {
                array[k] = derecha[j];
                j++;
            }
            k++;
        }

        while (i < izquierda.length) {
            array[k] = izquierda[i];
            i++;
            k++;
        }

        while (j < derecha.length) {
            array[k] = derecha[j];
            j++;
            k++;
        }
    }

    @Override
    public void mezclaDirecta() {
        if (!arrayVacio()) {
            mezclaDirecto(0, i);
            Tools.imprime("Datos del array ordenados por Mezcla directa:\n" + Arrays.toString(array));
        }
    }

    private void mezclaDirecto(int bajo, int alto) {
        if (bajo < alto) {
            int medio = (bajo + alto) / 2;
            mezclaDirecto(bajo, medio);
            mezclaDirecto(medio + 1, alto);
            Directo(bajo, medio, alto);
        }
    }

    private void Directo(int bajo, int medio, int alto) {
        int[] temp = new int[array.length];
        int i = bajo;
        int j = medio + 1;
        int k = bajo;

        while (i <= medio && j <= alto) {
            if (array[i] <= array[j]) {
                temp[k] = array[i];
                i++;
            } else {
                temp[k] = array[j];
                j++;
            }
            k++;
        }

        while (i <= medio) {
            temp[k] = array[i];
            i++;
            k++;
        }

        while (j <= alto) {
            temp[k] = array[j];
            j++;
            k++;
        }

        for (int x = bajo; x <= alto; x++) {
            array[x] = temp[x];
        }
    }

    @Override
    public void radix() {
        int n = i + 1;
        int max = maximo();

        for (int k = 1; max / k > 0; k *= 10) {
            conteo(n, k);
        }
            Tools.imprime("Datos del array ordenados por Radix:\n" + Arrays.toString(array));
    }

    private int maximo() {
        int max = array[0];
        for (int j = 1; j <= i; j++) {
            if (array[j] > max) {
                max = array[j];
            }
        }
        return max;
    }

    private void conteo(int n, int exp) {
        int[] arreglo = new int[n];
        int[] aux = new int[10];
        Arrays.fill(aux, 0);

        for (int j = 0; j <= i; j++) {
            aux[(array[j] / exp) % 10]++;
        }

        // se calculan las posiciones 
        for (int j = 1; j < 10; j++) {
            aux[j] += aux[j - 1];
        }

        // arreglo para la salida
        for (int j = i; j >= 0; j--) {
            arreglo[aux[(array[j] / exp) % 10] - 1] = array[j];
            aux[(array[j] / exp) % 10]--;
        }

        // se pasa el array de salida al que ya tenemos
        for (int j = 0; j <= i; j++) {
            array[j] = arreglo[j];
        }
    }
}
